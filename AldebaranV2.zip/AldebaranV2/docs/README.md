Aldebaran V2 minimal structure.
